/*
Author(s): Raphaela
Updated: 10/20/19
Description: Main program of the application
*/
#include <iostream>

using namespace std;

void send();
void input_new();
void new_menu();
void new_diagnose();
void new_disease();
void stats();
void send_msg();
void user_menu();
void user_mgmt();
void update_user();
void delete_user();
void list_users();
