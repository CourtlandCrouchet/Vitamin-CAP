/*
Author(s): Raphaela
Updated: 10/20/19
Description: Main program of the application
*/
#include <iostream>
#include "user.hpp"

void title();
void login();
void reg();
void listener();
void menu();
