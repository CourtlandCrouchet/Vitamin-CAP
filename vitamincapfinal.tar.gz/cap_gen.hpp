/*
Author(s): Raphaela
Updated: 10/20/19
Description: Main program of the application
*/
#include <iostream>
#include <fstream>

using namespace std;

#define MAX_HEADLINE_LENGTH  60
#define MAX_DESCRIPTION_LENGTH  200
#define MAX_INSTRUCTION_LENGTH  200

void gen_cap();
