/*
Author(s): Raphaela
Updated: 10/20/19
Description: Main program of the application
*/
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <string>
#include <iostream>
#include <fstream>
#include <streambuf>

using namespace std;

void error(char *msg);

void ConnectToUser(string hostname, int port);
