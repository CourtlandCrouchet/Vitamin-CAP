/*
Author(s): Raphaela
Updated: 10/20/19
Description: Main program of the application
*/
#include <string.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <vector>
#include "rapidxml-1.13/rapidxml.hpp"

using namespace rapidxml;
using namespace std;

void cap_parse();
